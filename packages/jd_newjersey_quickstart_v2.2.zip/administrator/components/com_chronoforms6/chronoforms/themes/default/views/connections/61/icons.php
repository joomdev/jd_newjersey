<?php
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
defined("GCORE_SITE") or die;
?>
<div class="ui horizontal list" style="position:absolute; top:0; right:0;">
	<div class="item">
		<i class="setting icon blue link edit_btn" data-hint="<?php el('Edit'); ?>"></i>
		<i class="sort icon orange link sort_btn" data-hint="<?php el('Sort'); ?>"></i>
		<i class="trash icon red link remove_btn" data-hint="<?php el('Remove'); ?>"></i>
	</div>
</div>