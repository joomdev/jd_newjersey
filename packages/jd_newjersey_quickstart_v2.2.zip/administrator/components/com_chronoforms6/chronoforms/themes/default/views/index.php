<?php
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
defined("GCORE_SITE") or die;
?>
<div class="ui container">
	<div class="ui header">Chronoforms 6 popular questions</div>
	<div class="ui relaxed divided list">
		
		<div class="item">
			<i class="large question middle aligned icon"></i>
			<div class="content">
				<a class="ui header small">{view:VIEW_NAME}</a>
				<div class="description">Display view, view must be created under the <div class="ui label blue">Views</div> tab.</div>
			</div>
		</div>
		
	</div>
</div>